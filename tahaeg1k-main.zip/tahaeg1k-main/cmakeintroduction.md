# Introduction to the basics of CMake 

The following link : https://cliutils.gitlab.io/modern-cmake/chapters/basics/comms.html
contains a very concise and interesting
introduction to using CMake for linking C++ projects.

The following general example https://gitlab.com/CLIUtils/modern-cmake/-/tree/master/examples/extended-project
also provides a nice structure which we are going to use 
set up our project environment. 

Also RTFM at https://cmake.org/cmake/help/latest/manual/cmake-buildsystem.7.html

At the end, I settled for one CMakeLists.txt file located 
at the folder options-pricing/. 
