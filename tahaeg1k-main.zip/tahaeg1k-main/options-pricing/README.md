# Pricing options using Monte Carlo

Calculate price, implied volatility of European options with Black Scholes' model, Binomial model and Monte Carlo method.
