# Documenting C++ code 

For documenting our code, following links are interesting :
- https://developer.lsst.io/cpp/api-docs.html#cpp-doxygen-sections
- https://zestedesavoir.com/tutoriels/822/la-programmation-en-c-moderne/etre-un-developpeur/mais-ou-est-la-doc/
- http://ccdoc.sourceforge.net/htdocs/introduction/introduction.htm
- https://www.cs.cmu.edu/~410/doc/doxygen.html
