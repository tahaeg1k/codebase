- 👋 Hi, I’m @tahaeg1k
- 👀 I’m interested in financial instrument pricing using C++.

Presentation of the project folder+file structure :
- This README gives you a quick presentation of the folder+file structure so that you can navigate around it.
- setup.md : is for setting up the C++ environment to run the project. We advise on having CLion installed from https://www.jetbrains.com/clion/download/#section=mac . It's efficient, and you can fork directly the project using the "Get from VCS" command on CLion. 
- structure.md : is for the structure of the project.
- cmakeintroduction.md : for an introduction the CMake tool for building C++ projects, it's efficient and platform independant.
- options-pricing : project folder that contains the project files. 

<!---
tahaeg1k/tahaeg1k is a ✨ special ✨ repository because its `README.md` (this file) appears on your GitHub profile.
You can click the Preview link to take a look at your changes.
--->


https://docs.github.com/en/repositories/working-with-files/managing-files/creating-new-files . 
